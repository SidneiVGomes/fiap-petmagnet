package br.com.fiap.magnet.com;

//@SpringBootTest
class PetMagnetApplicationTests {

//	@Test
	void contextLoads() {
	}

}
