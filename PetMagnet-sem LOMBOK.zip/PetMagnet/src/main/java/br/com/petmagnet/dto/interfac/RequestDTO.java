package br.com.petmagnet.dto.interfac;

public interface RequestDTO {
	public Object toEntity();
}
