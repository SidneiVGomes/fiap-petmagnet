$('.custom-datepicker').datepicker({
	format: "dd/mm/yyyy",
	orientation: "bottom",
	autoclose: "true",
	todayBtn: "linked",
	todayHighlight: "true",
	toggleActive: "true",
});

//$('.custom-datepickerr').on(
//        'dp.show',
//        function(e) {
//        $(".bootstrap-datetimepicker-widget").css(
//        "background-color", "#3c3e43");
//        });

//$(".btn").on("click", function(){
//	alert("Hello! I am an alert box!!");
//})