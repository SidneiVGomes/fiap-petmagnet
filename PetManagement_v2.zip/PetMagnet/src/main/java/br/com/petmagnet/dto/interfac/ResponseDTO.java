package br.com.petmagnet.dto.interfac;

import java.util.List;

public interface ResponseDTO {
	public List<Object> toList();
}
